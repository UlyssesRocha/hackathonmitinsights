var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var AddressSchema = new Schema({
    street: String,
    number: Number,
    neighborhood: String,
    city: String,
    state: String,
    country: {
        type: String,
        default: "BR"
    }
});

module.exports = mongoose.model('Address', AddressSchema);