var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var Address = require('./address');

var ImmobileSchema = new Schema({
    latitude: Number,
    longitude: Number,
    area: Number,
    address: {type: mongoose.Schema.Types.ObjectId, ref: 'Address'},
    rooms: Number,
    suites: Number,
    //1 - Sell, 2 - Rent
    offerType: {type: Number, enum: [1, 2], default: 1},
    //1 - Apartment, 2 - House
    type: {type: Number, enum: [1, 2], default: 1},
    parkingSpaces: {
        type: Number,
        default: 0
    },
    pools: Boolean,
    price: Number,
    bathrooms: Number,
    details: String,
    fitness: Boolean,
    photos: [String],
    playground: Boolean,
    monthlyPrice: Number
});

module.exports = mongoose.model('Immobile', ImmobileSchema);
