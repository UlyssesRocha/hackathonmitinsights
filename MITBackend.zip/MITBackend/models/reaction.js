var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var Immobile = require('./immobile');
var User = require('./user');

var ReactionSchema = new Schema({
    immobile: {type: mongoose.Schema.Types.ObjectId, ref: 'Immobile'},
    username: String,
    evaluation: {
        type: Number,
        enum: [-1, 1],
        default: 1
    }
});

module.exports = mongoose.model('Reaction', ReactionSchema);
