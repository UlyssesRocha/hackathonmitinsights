var express    = require('express');
var app        = express();
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var Address = require('./models/address');
var Immobile = require('./models/immobile');
var Reaction = require('./models/reaction');
var User = require('./models/user');

var port = process.env.PORT || 8080;

var router = express.Router();

var mongoose = require('mongoose');
mongoose.connect('mongodb://mitinsightbackend:mitinsightbackend@ds257495.mlab.com:57495/heroku_7nt23wgv');

function getInterest(reactions){
    var averageRooms = reactions
            .map(function(it){ return it.immobile.rooms; })
            .reduce(function(a, b){ return a+b; }, 0)/reactions.length;

    var averageBathrooms = reactions
            .map(function(it){ return it.immobile.bathrooms; })
            .reduce(function(a, b){ return a+b; }, 0)/reactions.length;

    var averageArea = reactions
            .map(function(it){ return it.immobile.area; })
            .reduce(function(a, b){ return a+b; }, 0)/reactions.length;

    var averageSuites = reactions
            .map(function(it){ return it.immobile.suites; })
            .reduce(function(a, b){ return a+b; }, 0)/reactions.length;

    return {
        rooms: averageRooms || 0,
        bathrooms: averageBathrooms || 0,
        area: averageArea || 0,
        suites: averageSuites || 0
    };

}

function getFitness(interest, immobile){
    return (
        Math.abs(interest.rooms - immobile.rooms)
        + Math.abs(interest.bathrooms - immobile.bathrooms)
        + Math.abs(interest.area - immobile.area)
        + Math.abs(interest.suites - immobile.suites)
    );
}

router.get('/all', function(req, res){
    Immobile.find().populate('address').lean().exec(function(err, immobiles){
        var proms = [];
        immobiles.forEach(function(immobile){
            proms.push(new Promise(function(resolve, reject){
                Reaction.find({immobile : immobile}).exec(function(err, reactions){
                    immobile.rating = reactions.map(function(re){ return re.evaluation || 0; }).reduce(function(a, b){ return a+b; }, 0);
                    resolve(true);
                });
            }));
        });

        Promise.all(proms).then(function(result){
            immobiles.sort(function(a, b){ return a.rating < b.rating; });
            res.json(immobiles);
        });

    });
});

router.get('/', function(req, res) {
    res.json({ message: 'hooray! welcome to our api!' });
});

router.route('/user')
    .post(function (req, res) {
        var user = new User();
        user.username = req.username;

        user.save(function(err){
            if(err){
                res.json({status: false, error: err});
            }else{
                res.json({status: true});
            }
        });
    });

router.route('/:username/interest')
    .get(function(req, res){
        var username = req.params.username;

        Reaction.find({username : username, evaluation: 1}).populate('immobile').exec(function(err, reactions){
            if(err){
                res.json({status: false, error: err});
            }else{
                res.json({status: true, interest: getInterest(reactions)})
            }
        });
    });

router.route('/:username/favorites')
    .get(function(req, res){
        var username = req.params.username;

        Reaction.find({
            evaluation: 1,
            username: username
        }).populate({path: 'immobile', model: 'Immobile', populate: { path: 'address', model: 'Address' }}).exec(function(err, reactions){
            if(err){
                res.json({status: false, error: err});
            }else {
                res.json({status: true, items: reactions});
            }
        });

    });

router.route('/:username/reaction')

    .post(function(req, res){
        var username = req.params.username;

        var reaction = new Reaction();
        reaction.evaluation = req.body.evaluation;
        reaction.username = username;
        reaction.immobile = req.body.immobile;

        reaction.save(function(err){
            if(err){
                res.json({status: false, error: err})
            }else{
                res.json({status: true})
            }
        });
    })

    .get(function(req, res){
        res.json({status: true})
    });

router.route('/immobile')

    .post(function(req, res){
        var address = new Address();

        address.street = req.body.street;
        address.number = req.body.number;
        address.neighborhood = req.body.neighborhood;
        address.city = req.body.city;
        address.state = req.body.state;
        address.country = req.body.country;

        address.save(function(err){
            if(err){
                res.json({status: false, error: err});
            }else{
                var immobile = new Immobile();
                immobile.address = address;
                immobile.area = req.body.area;
                immobile.rooms = req.body.rooms;
                immobile.suites = req.body.suites;
                immobile.offerType = req.body.offerType;
                immobile.type = req.body.type;
                immobile.parkingSpaces = req.body.parkingSpaces;
                immobile.pools = req.body.pools;
                immobile.price = req.body.price;
                immobile.bathrooms = req.body.bathrooms;
                immobile.details = req.body.details;
                immobile.fitness = req.body.fitness;
                immobile.photos = req.body.photos;
                immobile.playground = req.body.playground;
                immobile.monthlyPrice = req.body.monthlyPrice;

                immobile.save(function(err){
                    if(err){
                        res.json({status: false, error: err});
                    }else{
                        res.json({status: true, id: immobile.objectId});
                    }
                });
            }
        });
    });

router.route('/:username/immobile')
    .get(function(req, res){
        var username = req.params.username;

        Reaction.find({username: username}).populate('immobile').lean().exec(function(err, reactions){
            if(err){
                res.json({status: false, error: err});
            }else{
                var goodReactions = reactions.filter(function(it){ return it.evaluation == 1 });

                var interest = getInterest(goodReactions);

                Immobile.find().populate('address').lean().exec(function(err, immobiles){
                    if(err){
                        res.json({status: false, error: err});
                    }else{
                        var immobilesIds = reactions
                            .map(function(it){ return it.immobile });

                        immobiles = immobiles.filter( function(imm){ return immobilesIds.indexOf(imm) < 0; } );

                        immobiles.forEach(function(it){
                            it.difference = getFitness(interest, it);
                        });

                        immobiles.sort(function(a, b){
                            return a.difference < b.difference;
                        });

                        res.json({status: true, items: immobiles});
                    }
                });
            }
        });
    });

app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.use('/api', router);

app.listen(port);
console.log('Magic happens on port ' + port);